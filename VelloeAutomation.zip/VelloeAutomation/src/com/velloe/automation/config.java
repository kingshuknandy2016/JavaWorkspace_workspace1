package com.velloe.automation;

import org.openqa.selenium.WebDriver;

public class config {
	
public static WebDriver driver =null;

}
